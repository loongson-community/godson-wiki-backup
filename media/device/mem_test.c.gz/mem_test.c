#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/resource.h>

int main(int argc, char **argv)
{
	if (argc < 2) {
		fprintf(stderr, "usage: %s size_in_gb\n", argv[0]);
		return 1;
	}

	errno = 0;
	long mem_gb = strtol(argv[1], NULL, 10);
	if (errno != 0) {
		perror("strtol");
		return 1;
	}

	const size_t s = (size_t) mem_gb << 30;
	struct rlimit lim = {s + (1 << 30), s + (1 << 30)};

	if (setrlimit(RLIMIT_MEMLOCK, &lim) == -1) {
		perror("setrlimit");
		return 1;
	}

	if (mlockall(MCL_FUTURE) == -1) {
		perror("mlockall");
		return 1;
	}

	char *mem = mmap(NULL, s, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
	if (mem == MAP_FAILED) {
		perror("mmap");
		return 1;
	}

	return 0;
}
